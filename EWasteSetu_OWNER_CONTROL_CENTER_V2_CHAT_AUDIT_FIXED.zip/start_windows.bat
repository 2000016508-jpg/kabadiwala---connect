@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (echo Node.js 18+ is required. Install Node.js, then run this file again.&pause&exit /b 1)
echo Starting E-WasteSetu...
node server.js
pause
