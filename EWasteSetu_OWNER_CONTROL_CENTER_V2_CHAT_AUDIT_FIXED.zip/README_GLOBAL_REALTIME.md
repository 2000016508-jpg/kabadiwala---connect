# E-WasteSetu V15 — Global Real-Time Marketplace

This version keeps seller lots globally visible to every recycler connected to the same public E-WasteSetu backend.

## Important
For two people on different devices and different networks/cities to communicate, the Node server must be deployed on a public HTTPS host. Opening `index.html` directly or running localhost on each phone creates separate marketplaces.

Recommended setup:
1. Deploy this folder to a Node hosting service/server.
2. Keep `PORT` configured by the host.
3. Open the resulting HTTPS URL on both devices.
4. Seller creates a lot -> server stores it -> all recycler browsers receive the SSE event and refresh the marketplace.
5. The lot remains visible until its status becomes `Sold Out`.

The app does not filter published marketplace lots by seller/recycler identity.
