@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (echo Node.js 18+ is required. Install Node.js first.&pause&exit /b 1)
if not exist .env copy /y .env.example .env >nul
powershell -NoProfile -ExecutionPolicy Bypass -Command "$p='.env'; $lines=Get-Content $p; function SetV($n){$v=Read-Host ('Enter '+$n); $script:lines=@($script:lines | Where-Object {$_ -notmatch ('^'+[regex]::Escape($n)+'=')}); $script:lines+=($n+'='+$v)}; SetV 'TWILIO_ACCOUNT_SID'; SetV 'TWILIO_AUTH_TOKEN'; SetV 'TWILIO_VERIFY_SERVICE_SID'; Set-Content -Encoding UTF8 $p $lines"
echo.
echo Configuration saved to .env
node server.js
pause
