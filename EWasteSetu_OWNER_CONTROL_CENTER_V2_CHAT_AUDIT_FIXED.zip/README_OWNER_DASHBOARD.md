# E-WasteSetu Owner Dashboard

## Purpose
Private owner console for the presentation/production architecture. It reads marketplace data from the same backend and keeps server-side audit snapshots of marketplace updates. Offer `history[]` is shown as seller ↔ recycler conversation/negotiation history when the app stores those messages.

## Run
1. Install Node.js.
2. Run `npm install`.
3. Set `OWNER_ADMIN_KEY` in `.env` to a strong secret before real deployment.
4. Run `node server.js`.
5. Open `http://localhost:3000/owner-dashboard.html` **or double-click `owner-dashboard.html` in Chrome**. The dashboard now automatically connects to `http://localhost:3000` when opened as a local file.

Demo key in this build: `OWNER-DEMO-2026`. Change it before any real deployment.

## Data
- `marketplace-data.json`: live marketplace state.
- `owner-audit.json`: append-style server audit snapshots, including marketplace changes and owner conversation records.

For a real deployment, replace JSON storage with PostgreSQL/object storage, encrypt sensitive fields, add proper owner MFA/RBAC, backups, retention policies, and immutable audit storage.
