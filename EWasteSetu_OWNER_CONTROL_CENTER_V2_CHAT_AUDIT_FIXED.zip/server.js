const http=require('http');
const fs=require('fs');
const path=require('path');

const ROOT=__dirname;
const PUBLIC=path.join(ROOT,'ewaste_pay');

function loadEnv(){
  const p=path.join(ROOT,'.env');
  if(!fs.existsSync(p)) return;
  for(const raw of fs.readFileSync(p,'utf8').split(/\r?\n/)){
    const line=raw.trim();
    if(!line||line.startsWith('#')) continue;
    const i=line.indexOf('='); if(i<1) continue;
    const k=line.slice(0,i).trim(), v=line.slice(i+1).trim().replace(/^['"]|['"]$/g,'');
    if(!(k in process.env)) process.env[k]=v;
  }
}
loadEnv();

const PORT=Number(process.env.PORT||3000);
const OTP_MODE=(process.env.OTP_MODE||'free-test').trim().toLowerCase();
const FREE_TEST_NUMBERS=new Set((process.env.FREE_TEST_NUMBERS||'9999999999,8888888888').split(',').map(x=>x.trim()).filter(Boolean));
const FREE_TEST_OTP=String(process.env.FREE_TEST_OTP||'123456');
const sent=new Map();
const attempts=new Map();
const MARKET_FILE=path.join(ROOT,'marketplace-data.json');
const AUDIT_FILE=path.join(ROOT,'owner-audit.json');
const OWNER_ADMIN_KEY=process.env.OWNER_ADMIN_KEY||'OWNER-DEMO-2026';
let ownerAudit={events:[]};
try{if(fs.existsSync(AUDIT_FILE)) ownerAudit=JSON.parse(fs.readFileSync(AUDIT_FILE,'utf8'))||ownerAudit}catch(e){console.error('[AUDIT LOAD]',e.message)}
function saveAudit(){const tmp=AUDIT_FILE+'.tmp';fs.writeFileSync(tmp,JSON.stringify(ownerAudit,null,2));fs.renameSync(tmp,AUDIT_FILE)}
function auditSnapshot(reason, data){ownerAudit.events=ownerAudit.events||[];ownerAudit.events.push({id:'AUD-'+Date.now()+'-'+Math.random().toString(36).slice(2,7),at:new Date().toISOString(),reason, data}); if(ownerAudit.events.length>10000) ownerAudit.events=ownerAudit.events.slice(-10000); saveAudit()}
function auditMarketplaceDelta(previous,next){
  const po=Object.fromEntries((previous?.offers||[]).map(x=>[String(x.id),x]));
  const no=Object.fromEntries((next?.offers||[]).map(x=>[String(x.id),x]));
  for(const [id,o] of Object.entries(no)){
    const old=po[id];
    if(!old) auditSnapshot('offer-created',{offerId:id,lotId:o.lotId,seller:o.seller,sellerCompanyName:o.sellerCompanyName,recycler:o.recycler,recyclerCompanyName:o.recyclerCompanyName,status:o.status,message:o.lastMessage||'',history:o.history||[],offer:o});
    else {
      const oldHist=JSON.stringify(old.history||[]), newHist=JSON.stringify(o.history||[]);
      const changed=old.status!==o.status||old.lastMessage!==o.lastMessage||oldHist!==newHist||old.amount!==o.amount||old.weight!==o.weight;
      if(changed){
        const added=(o.history||[]).slice((old.history||[]).length);
        auditSnapshot('offer-updated',{offerId:id,lotId:o.lotId,seller:o.seller,sellerCompanyName:o.sellerCompanyName,recycler:o.recycler,recyclerCompanyName:o.recyclerCompanyName,status:o.status,message:o.lastMessage||'',newMessages:added,history:o.history||[],offer:o});
      }
    }
  }
  const pl=Object.fromEntries((previous?.lots||[]).map(x=>[String(x.id),x]));
  for(const l of next?.lots||[]){const old=pl[String(l.id)];if(!old)auditSnapshot('lot-created',{lot:l});else if(old.status!==l.status||old.soldAt!==l.soldAt)auditSnapshot('lot-status-changed',{lotId:l.id,from:old.status,to:l.status,lot:l});}
  const pr=Object.fromEntries((previous?.rates||[]).map(x=>[String(x.id),x]));
  for(const r of next?.rates||[]){if(!pr[String(r.id)])auditSnapshot('rate-created',{rate:r});}
}
function ownerAuthorized(req){return String(req.headers['x-owner-key']||'')===OWNER_ADMIN_KEY}
let marketplace={lots:[],offers:[],rates:[],auth:{}};
const realtimeClients=new Set();
function broadcastMarketplace(){const payload=`data: ${JSON.stringify({type:'marketplace-update',at:new Date().toISOString()})}\n\n`;for(const res of realtimeClients){try{res.write(payload)}catch(e){realtimeClients.delete(res)}}}
try{ if(fs.existsSync(MARKET_FILE)) marketplace=JSON.parse(fs.readFileSync(MARKET_FILE,'utf8'))||marketplace; }catch(e){ console.error('[MARKET LOAD]',e.message); }
function saveMarketplace(){ const tmp=MARKET_FILE+'.tmp'; fs.writeFileSync(tmp,JSON.stringify(marketplace,null,2)); fs.renameSync(tmp,MARKET_FILE); }
function cleanMarketplace(x){ return {lots:Array.isArray(x?.lots)?x.lots:[],offers:Array.isArray(x?.offers)?x.offers:[],rates:Array.isArray(x?.rates)?x.rates:[],auth:x?.auth&&typeof x.auth==='object'?x.auth:{}}; }
function mergeById(current,incoming){
  const map=new Map();
  for(const item of Array.isArray(current)?current:[]){ if(item&&item.id!=null) map.set(String(item.id),item); }
  for(const item of Array.isArray(incoming)?incoming:[]){ if(item&&item.id!=null) map.set(String(item.id),item); }
  return [...map.values()];
}
function mergeMarketplace(next){
  const n=cleanMarketplace(next);
  marketplace=cleanMarketplace(marketplace);
  return {
    lots:mergeById(marketplace.lots,n.lots),
    offers:mergeById(marketplace.offers,n.offers),
    rates:mergeById(marketplace.rates,n.rates),
    auth:{...(marketplace.auth||{}),...(n.auth||{})}
  };
}

function json(res,status,data){
  res.writeHead(status,{
    'Content-Type':'application/json; charset=utf-8',
    'Cache-Control':'no-store',
    'Access-Control-Allow-Origin':'*',
    'Access-Control-Allow-Headers':'Content-Type, X-Owner-Key'
  });
  res.end(JSON.stringify(data));
}
function readBody(req){return new Promise((resolve,reject)=>{let b='';req.on('data',c=>{b+=c;if(b.length>100000) req.destroy();});req.on('end',()=>{try{resolve(JSON.parse(b||'{}'));}catch(e){reject(new Error('Invalid JSON request.'));}});req.on('error',reject);});}
function indianPhone(v){
  let d=String(v??'').replace(/\D/g,'');
  if(d.startsWith('91')&&d.length===12)d=d.slice(2);
  return /^([6-9]\d{9})$/.test(d)?d:null;
}
function config(){
  const service=process.env.TWILIO_VERIFY_SERVICE_SID||'';
  const apiSid=process.env.TWILIO_API_KEY_SID||'';
  const apiSecret=process.env.TWILIO_API_KEY_SECRET||'';
  const account=process.env.TWILIO_ACCOUNT_SID||'';
  const token=process.env.TWILIO_AUTH_TOKEN||'';
  const authOk=(apiSid&&apiSecret)||(account&&token);
  return {service,authOk,apiSid,apiSecret,account,token};
}
function publicConfig(){const c=config();return {mode:OTP_MODE,freeTestMode:OTP_MODE==='free-test',configured:Boolean(c.service&&c.authOk),serviceFormat:/^VA[0-9a-f]{32}$/i.test(c.service),authMethod:c.apiSid&&c.apiSecret?'api-key':(c.account&&c.token?'account-auth':'missing'),node:process.version};}
function authHeader(c){
  if(c.apiSid&&c.apiSecret) return 'Basic '+Buffer.from(c.apiSid+':'+c.apiSecret).toString('base64');
  return 'Basic '+Buffer.from(c.account+':'+c.token).toString('base64');
}
async function twilio(pathPart,form){
  const c=config();
  if(!c.service) throw new Error('Twilio Verify Service SID is missing. Add TWILIO_VERIFY_SERVICE_SID=VA... to .env.');
  if(!c.authOk) throw new Error('Twilio credentials are missing. Add Account SID + Auth Token OR API Key SID + API Key Secret to .env.');
  const url=`https://verify.twilio.com/v2/Services/${encodeURIComponent(c.service)}/${pathPart}`;
  const controller=new AbortController(); const timer=setTimeout(()=>controller.abort(),15000);
  try{
    const r=await fetch(url,{method:'POST',headers:{Authorization:authHeader(c),'Content-Type':'application/x-www-form-urlencoded','Accept':'application/json'},body:new URLSearchParams(form),signal:controller.signal});
    const text=await r.text(); let d={}; try{d=JSON.parse(text);}catch{}
    if(!r.ok){
      const code=d.code?` [Twilio ${d.code}]`:'';
      throw new Error((d.message||`Twilio returned HTTP ${r.status}.`)+code);
    }
    return d;
  }finally{clearTimeout(timer);}
}
function rateLimit(map,key,ms){const now=Date.now(),last=map.get(key)||0;if(now-last<ms)return Math.ceil((ms-(now-last))/1000);map.set(key,now);return 0;}

const server=http.createServer(async(req,res)=>{
  try{
    if(req.method==='OPTIONS'){res.writeHead(204,{'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type, X-Owner-Key'});return res.end();}
    const pathname=new URL(req.url,'http://localhost').pathname;

    if(req.method==='GET'&&pathname==='/api/config'){ return json(res,200,{ok:true,apiBase:process.env.PUBLIC_API_BASE_URL||''}); }

    if(req.method==='GET'&&pathname==='/api/owner/dashboard'){
      if(!ownerAuthorized(req)) return json(res,401,{ok:false,error:'Owner authentication required.'});
      marketplace=cleanMarketplace(marketplace);
      return json(res,200,{ok:true,marketplace,audit:ownerAudit,serverTime:new Date().toISOString()});
    }
    if(req.method==='POST'&&pathname==='/api/owner/conversation'){
      if(!ownerAuthorized(req)) return json(res,401,{ok:false,error:'Owner authentication required.'});
      const b=await readBody(req); const c=b.conversation||b.message||b;
      auditSnapshot('conversation', c);
      return json(res,200,{ok:true,saved:true});
    }
    if(req.method==='GET'&&pathname==='/api/marketplace'){
      marketplace=cleanMarketplace(marketplace);
      return json(res,200,{ok:true,data:marketplace,updatedAt:new Date().toISOString()});
    }

    if(req.method==='PUT'&&pathname==='/api/marketplace'){
      const b=await readBody(req);
      const before=JSON.parse(JSON.stringify(marketplace));
      marketplace=mergeMarketplace(b.data);
      saveMarketplace();
      auditMarketplaceDelta(before, marketplace);
      auditSnapshot('marketplace-update',{summary:{lots:marketplace.lots.length,offers:marketplace.offers.length,rates:marketplace.rates.length}});
      broadcastMarketplace();
      return json(res,200,{ok:true,data:marketplace,updatedAt:new Date().toISOString()});
    }

    if(req.method==='POST'&&pathname==='/api/marketplace/lot'){
      const b=await readBody(req);
      const lot=b.lot;
      if(!lot||typeof lot!=='object'||!lot.id) return json(res,400,{ok:false,error:'Invalid lot.'});
      marketplace=cleanMarketplace(marketplace);
      const existing=marketplace.lots.find(x=>String(x.id)===String(lot.id));
      if(!existing) marketplace.lots.push(lot);
      saveMarketplace();
      broadcastMarketplace();
      return json(res,200,{ok:true,data:marketplace,lot:marketplace.lots.find(x=>String(x.id)===String(lot.id)),updatedAt:new Date().toISOString()});
    }

    if(req.method==='GET'&&pathname==='/api/marketplace/events'){
      res.writeHead(200,{'Content-Type':'text/event-stream; charset=utf-8','Cache-Control':'no-cache, no-store, must-revalidate','Connection':'keep-alive','Access-Control-Allow-Origin':'*'});
      res.write(`data: ${JSON.stringify({type:'connected',at:new Date().toISOString()})}\n\n`);
      realtimeClients.add(res);
      req.on('close',()=>realtimeClients.delete(res));
      return;
    }

    if(req.method==='GET'&&pathname==='/owner-dashboard.html'){
      const f=path.join(ROOT,'owner-dashboard.html'); if(!fs.existsSync(f)) return text(res,404,'Owner dashboard not found');
      res.writeHead(200,{'Content-Type':'text/html; charset=utf-8'}); return res.end(fs.readFileSync(f));
    }
    if(req.method==='GET'&&pathname==='/api/health'){
      const c=publicConfig();
      return json(res,200,{ok:true,smsProvider:'twilio-verify-v2',...c,now:new Date().toISOString()});
    }

    if(req.method==='POST'&&pathname==='/api/send-otp'){
      const b=await readBody(req), p=indianPhone(b.phone);
      if(!p) return json(res,400,{ok:false,error:'Enter a valid Indian mobile number (10 digits starting 6-9).'});
      const wait=rateLimit(sent,p,30000); if(wait)return json(res,429,{ok:false,error:`Please wait ${wait} seconds before requesting another OTP.`});
      if(OTP_MODE==='free-test'){
        if(!FREE_TEST_NUMBERS.has(p)) return json(res,400,{ok:false,error:`Free mode is enabled. Use a test number configured by the app: ${Array.from(FREE_TEST_NUMBERS).join(', ')}. No real SMS is sent in free mode.`});
        sent.set(p,Date.now());
        return json(res,200,{ok:true,sent:true,testMode:true,status:'pending',message:'Free test OTP ready. No SMS is sent in free mode.'});
      }
      const channel=String(b.channel||'sms').toLowerCase()==='whatsapp'?'whatsapp':'sms';
      const d=await twilio('Verifications',{To:'+91'+p,Channel:channel});
      return json(res,200,{ok:true,sent:true,channel,status:d.status||'pending',message:channel==='whatsapp'?'OTP sent on WhatsApp.':'OTP sent by SMS.'});
    }

    if(req.method==='POST'&&pathname==='/api/verify-otp'){
      const b=await readBody(req), p=indianPhone(b.phone), otp=String(b.otp||'').trim();
      if(!p||!/^[0-9]{4,10}$/.test(otp)) return json(res,400,{ok:false,verified:false,error:'Enter the OTP exactly as received by SMS or WhatsApp.'});
      const key=p, count=attempts.get(key)||0; if(count>=5)return json(res,429,{ok:false,verified:false,error:'Too many incorrect OTP attempts. Request a new OTP and try again.'});
      if(OTP_MODE==='free-test'){
        if(!FREE_TEST_NUMBERS.has(p)) return json(res,400,{ok:false,verified:false,error:'This number is not enabled for free test OTP mode.'});
        if(otp===FREE_TEST_OTP){ attempts.delete(key); sent.delete(key); return json(res,200,{ok:true,verified:true,status:'approved',testMode:true}); }
        attempts.set(key,count+1); return json(res,401,{ok:false,verified:false,error:'Test OTP is incorrect. In free mode use the configured test OTP.'});
      }
      try{
        const d=await twilio('VerificationCheck',{To:'+91'+p,Code:otp});
        if(d.status==='approved'){attempts.delete(key);sent.delete(key);return json(res,200,{ok:true,verified:true,status:'approved'});}
        attempts.set(key,count+1);return json(res,401,{ok:false,verified:false,error:'OTP is not verified. Try again.'});
      }catch(e){
        attempts.set(key,count+1);return json(res,401,{ok:false,verified:false,error:e.message||'OTP verification failed. Try again.'});
      }
    }

    if(req.method==='GET'){
      const u=new URL(req.url,'http://localhost');
      let rel=u.pathname==='/'?'/index.html':u.pathname;
      try{rel=decodeURIComponent(rel);}catch{}
      const fp=path.resolve(PUBLIC,'.'+rel);
      if(!fp.startsWith(path.resolve(PUBLIC)+path.sep))return json(res,403,{error:'Forbidden'});
      fs.readFile(fp,(e,data)=>{if(e){res.writeHead(404,{'Content-Type':'text/plain; charset=utf-8'});return res.end('Not found');}
        const ext=path.extname(fp).toLowerCase();const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json'};
        res.writeHead(200,{'Content-Type':types[ext]||'application/octet-stream','Cache-Control':'no-store'});res.end(data);
      });return;
    }
    json(res,404,{error:'Not found'});
  }catch(e){console.error('[SERVER ERROR]',e);json(res,500,{ok:false,error:e.message||'Server error'});}
});
server.listen(PORT,()=>{console.log(`E-WasteSetu running: http://localhost:${PORT}`);console.log('SMS configuration:',publicConfig());});
