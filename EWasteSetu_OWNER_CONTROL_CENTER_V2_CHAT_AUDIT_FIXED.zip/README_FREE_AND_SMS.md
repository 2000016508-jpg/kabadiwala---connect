E-WasteSetu OTP — FREE MODE + REAL SMS MODE

IMPORTANT: A real SMS to an arbitrary Indian mobile number cannot be guaranteed at ₹0. SMS delivery requires a carrier/SMS provider and providers charge for production SMS. Firebase also documents that phone authentication is billed per SMS in production; its no-SMS test-number mode is free.

FREE MODE (works without Twilio, no payment, no SMS)
1. Keep OTP_MODE=free-test in .env.
2. Run start_windows.bat or: node server.js
3. Open http://localhost:3000 (do not open index.html directly).
4. Use test mobile: 9999999999 or 8888888888
5. Use test OTP: 123456
This mode is for development/demo only. It does NOT verify ownership of a real phone number.

REAL SMS MODE
1. Set OTP_MODE=twilio.
2. Fill Twilio Verify credentials in .env.
3. Restart server.
4. Open http://localhost:3000.
5. GET /api/health must show mode=twilio and configured=true.

WHY THERE IS NO HONESTLY FREE REAL-SMS SOLUTION
The app cannot manufacture an SMS on a carrier network for free. Any website claiming unlimited real SMS OTP to arbitrary numbers at zero cost is not a reliable production architecture.

For a zero-cost SIH/demo, use FREE MODE. For real users, switch to a compliant SMS provider or Firebase Phone Auth with the required billing setup.


UI / MARKETPLACE V5
- Opening the site shows a 3-second animated E-WasteSetu intro screen with recycling/marketplace motion.
- Seller enters a base selling amount; the UI automatically adds GST at 18% and displays Base + GST + Final amount incl. GST.
- Recycler sees the GST-inclusive seller amount.
- Recycler offers and both seller/recycler corrections support changing weight AND base amount.
- Every correction recalculates GST at 18% and shows the updated GST-inclusive amount to the other side for confirmation.
- Once the recycler confirms payment, the prototype records the payment as confirmed/released to the seller. No real money is transferred by this local demo.
