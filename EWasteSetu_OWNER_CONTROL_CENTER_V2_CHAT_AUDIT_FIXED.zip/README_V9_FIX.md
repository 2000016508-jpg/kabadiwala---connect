# E-WasteSetu V9 — Marketplace Sync + 3-Way Lot Response Fix

## What is fixed
1. Seller can reliably see recycler offers using normalized email/mobile identity matching.
2. Recycler sees **Accept / Denied / Make Offer** directly on every published seller lot.
3. Recycler **Accept** creates a response for that exact lot and seller immediately gets **Accept / Denied / Make Offer**.
4. Recycler **Make Offer** continues to create a normal negotiable offer.
5. Seller responses automatically appear for the recycler without logout/login.
6. Marketplace data is now synced through the Node backend at `/api/marketplace`, so two phones/browsers using the **same running server URL** can share lots/offers.
7. LocalStorage remains as a fallback/cache, while the backend is the shared source for cross-device demo synchronization.

## Important
Do NOT open `index.html` directly with `file://`. Start the Node server:

    npm install
    npm start

Then open:

    http://localhost:3000

For two physical phones on the same Wi-Fi, run the server on a computer reachable by both phones and open the computer's LAN URL, for example:

    http://192.168.x.x:3000

Both devices must use the same server URL. LocalStorage/BroadcastChannel alone cannot synchronize two physical devices.

## Marketplace storage
The shared demo marketplace is stored in `marketplace-data.json`. This is a prototype datastore, not production database infrastructure. For production, replace it with PostgreSQL/Firestore/etc. with authentication, authorization, transactions, and audit logging.
