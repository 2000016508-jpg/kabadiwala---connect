@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 18+ is required.
  echo Install Node.js from https://nodejs.org/ and run this file again.
  pause
  exit /b 1
)
echo ==============================================
echo        E-WasteSetu - Starting Server
echo ==============================================
start "E-WasteSetu Browser" http://localhost:3000
node server.js
pause
