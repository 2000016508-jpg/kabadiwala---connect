# E-WasteSetu Owner Control Center — Fixed

## What was fixed
1. Owner dashboard no longer fails when API URLs contain `?ts=...` query parameters. The server now routes by URL pathname.
2. Opening `owner-dashboard.html` directly in Chrome no longer shows a blocking backend error; it falls back to local presentation mode.
3. `OPEN_OWNER_CONSOLE.bat` starts the Node server and opens the owner console from the server, which is the recommended live mode.
4. The server keeps up to 10,000 audit events in `owner-audit.json`.
5. Every offer create/update is audited, including status changes, amount/weight corrections, last messages, and newly added history entries.
6. The marketplace now supports a private seller↔recycler chat attached to each offer. Each message is stored in the offer `chat` array and also in `history` as a Chat message, then persisted by the backend.
7. Owner console has separate views for complete conversations, offer decision timelines, lots, rates, and audit events.

## Recommended live start
Double-click:
OPEN_OWNER_CONSOLE.bat

Then use:
http://localhost:3000/owner-dashboard.html

Owner demo key:
OWNER-DEMO-2026

## Data files
- marketplace-data.json — marketplace state
- owner-audit.json — server-side audit history

Do not publish these JSON files or the owner key. For a real production deployment, replace the demo key and JSON storage with proper authentication, PostgreSQL, encrypted secrets, backups, and access controls.

## Presentation/offline mode
You may double-click owner-dashboard.html directly. If the server is unavailable, the dashboard opens in local presentation mode instead of showing a fatal backend error. Live seller/recycler data requires the backend to be running.
