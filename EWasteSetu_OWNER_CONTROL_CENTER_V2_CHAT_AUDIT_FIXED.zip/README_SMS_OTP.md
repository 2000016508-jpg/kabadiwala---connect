# E-WasteSetu — REAL SMS OTP (fixed)

This build uses the Twilio Verify v2 server-side workflow: the browser asks the backend to start an SMS verification, Twilio sends the code, and the backend checks the code with Twilio. The OTP is never generated or shown by the website.

## Start on Windows
1. Install Node.js 18+.
2. Double-click `setup_windows.bat`.
3. Enter your real Twilio values when prompted.
4. Keep the command window running.
5. Open **http://localhost:3000** — do not open `index.html` directly.
6. Test `http://localhost:3000/api/health`. You want `configured:true` and `serviceFormat:true`.

## Manual setup
Copy `.env.example` to `.env` and fill either:
- `TWILIO_ACCOUNT_SID` + `TWILIO_AUTH_TOKEN`, OR
- `TWILIO_API_KEY_SID` + `TWILIO_API_KEY_SECRET`.

Always fill `TWILIO_VERIFY_SERVICE_SID` with the `VA...` SID of your Verify Service.

## If the SMS still does not arrive
The server now returns Twilio's actual error code/message instead of hiding it. Check the terminal and the red message in the login screen.

For India, SMS delivery can also depend on Twilio's geographic permissions and Indian carrier/compliance routing. Twilio documents international and domestic India routes separately; domestic routes can require DLT registration. A Twilio trial account also requires recipient verification.

## Security
Never put Twilio secrets in `index.html`, GitHub, or chat. The `.env` file stays server-side.
