# E-WasteSetu — All Indian Language Entry Selection

This version adds a language-selection screen at website entry and a language switcher that remains available while using the app.

Supported languages: the 22 languages in the Eighth Schedule of the Constitution of India, plus English. The selector also includes Bhojpuri as an extra regional option.

The page is translated dynamically with Google Translate, so an internet connection is required for translation. The original E-WasteSetu data, marketplace logic, login, offers, rate deals and realtime backend are unchanged.

Selected language is remembered in the browser and can be changed at any time from the floating language selector.

Important for production: dynamic third-party translation should be replaced or supplemented with professionally reviewed application translation files if the app must work fully offline or if legal/financial wording must be guaranteed in every language.
