E-WasteSetu V7

- Recycler receives Seller response without logout/login.
- Seller and Recycler each get Accept / Denied / Make Offer when the other side sends a correction.
- Corrections can change weight and base amount; GST 18% recalculates.
- After Recycler advance payment, Seller must upload a certificate and enter the certificate email/mobile. The contact must match the Seller registered login identity.
- After certificate verification, Recycler can confirm remaining payment.
- Each browser tab keeps its own login session while marketplace data is shared through localStorage/BroadcastChannel, preventing one tab logout from logging the other out.
- Auto-refresh polling keeps the current screen updated; no logout/login is needed.
- This is a prototype: cross-device real-time sync requires a hosted shared database/backend.
