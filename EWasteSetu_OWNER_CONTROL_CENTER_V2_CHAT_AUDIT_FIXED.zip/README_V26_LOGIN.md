# E-WasteSetu V26 — UI/UX Demo Login Fix

## Login protection
- The Security PIN gate now runs on localhost/HTTPS as well as file-based demos.
- First successful login on a device: create a 6-digit PIN and confirm it.
- Later logins: enter the PIN.
- Inactivity lock: 10 minutes.
- PIN is stored as a SHA-256 hash in localStorage for this presentation demo.

## OTP
Phone login now offers:
- SMS
- WhatsApp

The selected channel is sent to the backend. With Twilio Verify configured, the backend uses the selected Verify channel. Free-test mode remains demo-only and does not send real messages.

### Real delivery
Configure Twilio Verify credentials in the server `.env`. Never place Twilio credentials in the frontend.

For WhatsApp OTP, the Twilio Verify service/account must be enabled/configured for WhatsApp delivery. SMS uses the standard Verify SMS channel.
